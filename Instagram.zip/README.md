# InstagramKit
PHP Curl Instagram

## Installation
```bash
composer require riedayme/instagramkit dev-master
```

## Usage The Script
```
View on examples folder
```

## Featured Scripts Ready to Run
* Follow DM Like
* Repost Target
* Mass Downloader People

## Change Log
**24 Juli 2020**
- Fix Mass Downloader
- Add Repost Target

**16 Juli 2020**
- Auth Using Facebook API

**30 Juni 2020**
- Add Script FDL

**20 Juni 2020**
- Add Scripts Story Vote Kuy
- Fix Bug

**6 Juni 2020**
- Release

**10 Juni 2020**
- Fix Bug
- Add Story script